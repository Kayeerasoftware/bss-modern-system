<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class CalculateInterest extends Command
{
    protected $signature = 'interest:calculate';
    protected $description = 'Calculate interest';

    public function handle()
    {
        //
    }
}
