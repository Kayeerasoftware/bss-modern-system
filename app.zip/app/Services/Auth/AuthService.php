<?php

namespace App\Services\Auth;

class AuthService
{
    //
}
