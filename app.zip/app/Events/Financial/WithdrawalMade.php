<?php

namespace App\Events\Financial;

use Illuminate\Foundation\Events\Dispatchable;

class WithdrawalMade
{
    use Dispatchable;
}
