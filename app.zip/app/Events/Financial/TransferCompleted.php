<?php

namespace App\Events\Financial;

use Illuminate\Foundation\Events\Dispatchable;

class TransferCompleted
{
    use Dispatchable;
}
