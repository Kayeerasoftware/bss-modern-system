<?php

namespace App\Http\Controllers\Api\Fundraising;

use App\Http\Controllers\Controller;

class FundraisingController extends Controller
{
    //
}
