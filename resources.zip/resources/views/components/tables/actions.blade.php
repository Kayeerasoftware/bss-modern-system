<div class="flex space-x-2">
    {{ $slot }}
</div>
