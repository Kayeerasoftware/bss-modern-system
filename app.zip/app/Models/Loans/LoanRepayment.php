<?php

namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class LoanRepayment extends Model
{
    //
}
