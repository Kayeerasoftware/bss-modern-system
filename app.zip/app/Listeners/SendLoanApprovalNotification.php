<?php

namespace App\Listeners;

class SendLoanApprovalNotification
{
    public function handle($event)
    {
        //
    }
}
