<div class="bg-white rounded-lg shadow p-6">
    <h2 class="text-xl font-bold mb-4">Settings</h2>
</div>
