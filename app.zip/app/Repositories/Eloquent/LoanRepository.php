<?php

namespace App\Repositories\Eloquent;

use App\Repositories\Interfaces\LoanRepositoryInterface;

class LoanRepository implements LoanRepositoryInterface
{
    //
}
