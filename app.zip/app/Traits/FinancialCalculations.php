<?php

namespace App\Traits;

trait FinancialCalculations
{
    //
}
