<?php

namespace App\Events\Member;

use Illuminate\Foundation\Events\Dispatchable;

class MemberUpdated
{
    use Dispatchable;
}
