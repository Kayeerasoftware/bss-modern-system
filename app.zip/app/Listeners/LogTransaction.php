<?php

namespace App\Listeners;

class LogTransaction
{
    public function handle($event)
    {
        //
    }
}
