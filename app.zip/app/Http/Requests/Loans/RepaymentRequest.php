<?php

namespace App\Http\Requests\Loans;

use Illuminate\Foundation\Http\FormRequest;

class RepaymentRequest extends FormRequest
{
    public function rules()
    {
        return [];
    }
}
