<?php

namespace App\Http\Controllers\Api\Loans;

use App\Http\Controllers\Controller;

class LoanController extends Controller
{
    //
}
