// Cashier Dashboard - Topbar is connected via Alpine.js in layout
console.log('Cashier Dashboard loaded');
