<?php

namespace App\Repositories\Eloquent;

use App\Repositories\Interfaces\MemberRepositoryInterface;

class MemberRepository implements MemberRepositoryInterface
{
    //
}
