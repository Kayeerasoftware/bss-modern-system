<?php

return [
    'failed' => 'Taarifa hizi hazifanani na rekodi zetu.',
    'password' => 'Nenosiri lililoingizwa si sahihi.',
    'throttle' => 'Majaribio mengi ya kuingia. Tafadhali jaribu tena baada ya sekunde :seconds.',
];
