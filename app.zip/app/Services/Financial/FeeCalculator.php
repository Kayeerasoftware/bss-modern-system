<?php

namespace App\Services\Financial;

class FeeCalculator
{
    //
}
