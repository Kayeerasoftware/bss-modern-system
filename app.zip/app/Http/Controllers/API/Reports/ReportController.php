<?php

namespace App\Http\Controllers\Api\Reports;

use App\Http\Controllers\Controller;

class ReportController extends Controller
{
    //
}
