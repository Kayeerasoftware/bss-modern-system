<?php

namespace App\Services\Loan;

class LoanService
{
    //
}
