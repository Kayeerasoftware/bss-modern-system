<?php

namespace App\Events\Member;

use Illuminate\Foundation\Events\Dispatchable;

class MemberRegistered
{
    use Dispatchable;
}
