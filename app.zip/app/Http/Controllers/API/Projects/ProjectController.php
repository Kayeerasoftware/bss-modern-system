<?php

namespace App\Http\Controllers\Api\Projects;

use App\Http\Controllers\Controller;

class ProjectController extends Controller
{
    //
}
