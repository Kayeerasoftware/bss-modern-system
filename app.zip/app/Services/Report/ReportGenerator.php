<?php

namespace App\Services\Report;

class ReportGenerator
{
    //
}
