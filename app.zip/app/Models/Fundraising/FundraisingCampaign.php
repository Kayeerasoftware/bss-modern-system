<?php

namespace App\Models\Fundraising;

use Illuminate\Database\Eloquent\Model;

class FundraisingCampaign extends Model
{
    //
}
