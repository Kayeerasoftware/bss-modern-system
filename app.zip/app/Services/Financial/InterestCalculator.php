<?php

namespace App\Services\Financial;

class InterestCalculator
{
    //
}
