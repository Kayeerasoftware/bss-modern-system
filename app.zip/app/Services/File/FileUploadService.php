<?php

namespace App\Services\File;

class FileUploadService
{
    //
}
