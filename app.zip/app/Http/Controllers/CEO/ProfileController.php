<?php

namespace App\Http\Controllers\CEO;

use App\Http\Controllers\Admin\ProfileController as AdminProfileController;

class ProfileController extends AdminProfileController {}
