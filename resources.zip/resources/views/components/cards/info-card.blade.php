<div class="bg-white rounded-lg shadow p-6">
    <h3 class="text-lg font-semibold mb-4">{{ $title }}</h3>
    <div class="text-gray-700">
        {{ $slot }}
    </div>
</div>
