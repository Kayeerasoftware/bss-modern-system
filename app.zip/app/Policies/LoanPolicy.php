<?php

namespace App\Policies;

class LoanPolicy
{
    //
}
