<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <h2 class="text-3xl font-bold text-gray-800">Projects</h2>
</div>

<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold mb-2"><?php echo e($project->name); ?></h3>
        <p class="text-gray-600 text-sm mb-4"><?php echo e(Str::limit($project->description, 100)); ?></p>
        <div class="mb-4">
            <div class="flex justify-between text-sm mb-1">
                <span>Progress</span>
                <span><?php echo e($project->progress); ?>%</span>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
                <div class="bg-blue-600 h-2 rounded-full" style="width: <?php echo e($project->progress); ?>%"></div>
            </div>
        </div>
        <a href="<?php echo e(route('td.projects.show', $project->id)); ?>" class="text-blue-600 hover:text-blue-900">View Details</a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-span-3 bg-white rounded-lg shadow p-6 text-center text-gray-500">No projects</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.td', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\Bss test\bss system new\resources\views/td/projects/index.blade.php ENDPATH**/ ?>