<?php

namespace App\Traits;

trait HasSettings
{
    //
}
