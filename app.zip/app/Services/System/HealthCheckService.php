<?php

namespace App\Services\System;

class HealthCheckService
{
    //
}
