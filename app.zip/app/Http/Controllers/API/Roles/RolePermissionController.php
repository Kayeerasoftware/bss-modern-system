<?php

namespace App\Http\Controllers\Api\Roles;

use App\Http\Controllers\Controller;

class RolePermissionController extends Controller
{
    //
}
