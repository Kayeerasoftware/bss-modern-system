<?php

namespace App\Http\Controllers\Api\System;

use App\Http\Controllers\Controller;

class AuditController extends Controller
{
    //
}
