<?php

namespace App\Models\Loans;

use Illuminate\Database\Eloquent\Model;

class Loan extends Model
{
    //
}
