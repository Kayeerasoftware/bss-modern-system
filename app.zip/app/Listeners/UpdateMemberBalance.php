<?php

namespace App\Listeners;

class UpdateMemberBalance
{
    public function handle($event)
    {
        //
    }
}
