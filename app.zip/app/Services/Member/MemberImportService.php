<?php

namespace App\Services\Member;

class MemberImportService
{
    //
}
