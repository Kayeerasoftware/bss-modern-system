<?php

namespace App\Http\Controllers\TD;

use App\Http\Controllers\Admin\MemberController as AdminMemberController;

class MemberController extends AdminMemberController
{
    // TD has read-only access to members
}
