<?php

namespace App\Models\Financial;

use Illuminate\Database\Eloquent\Model;

class Deposit extends Model
{
    //
}
