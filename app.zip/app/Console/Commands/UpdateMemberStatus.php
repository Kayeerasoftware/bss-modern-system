<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class UpdateMemberStatus extends Command
{
    protected $signature = 'members:update-status';
    protected $description = 'Update member status';

    public function handle()
    {
        //
    }
}
