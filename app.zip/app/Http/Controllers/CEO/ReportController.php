<?php

namespace App\Http\Controllers\CEO;

use App\Http\Controllers\Admin\ReportController as AdminReportController;

class ReportController extends AdminReportController {}
