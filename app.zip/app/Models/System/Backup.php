<?php

namespace App\Models\System;

use Illuminate\Database\Eloquent\Model;

class Backup extends Model
{
    //
}
