<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-3 md:p-6">
    <div class="mb-4 md:mb-6">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
            <div class="flex items-center gap-2 md:gap-4">
                <div class="relative">
                    <div class="absolute inset-0 bg-gradient-to-r from-green-600 to-teal-600 rounded-xl blur-xl opacity-50"></div>
                    <div class="relative bg-gradient-to-br from-green-600 to-teal-600 p-2 md:p-4 rounded-xl shadow-xl">
                        <i class="fas fa-arrow-down text-white text-xl md:text-3xl"></i>
                    </div>
                </div>
                <div>
                    <h1 class="text-xl md:text-3xl font-bold bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent mb-1">Deposits</h1>
                    <p class="text-gray-600 text-xs md:text-sm font-medium">All deposit transactions</p>
                </div>
            </div>
            <a href="<?php echo e(route('cashier.deposits.create')); ?>" class="px-4 py-2 bg-gradient-to-r from-green-600 to-teal-600 text-white rounded-lg hover:shadow-xl transition text-sm font-bold">
                <i class="fas fa-plus mr-1"></i>New Deposit
            </a>
        </div>
    </div>

    <div class="relative h-2 bg-gray-200 rounded-full overflow-visible mb-4">
        <div class="h-full bg-gradient-to-r from-green-500 to-teal-600 rounded-full animate-slide-right"></div>
        <span class="absolute -top-6 text-2xl text-green-600 font-bold animate-slide-text whitespace-nowrap z-10">Loading Deposits data...</span>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
        <div class="bg-gradient-to-br from-green-500 to-green-600 rounded-lg p-2 md:p-3 text-white shadow-lg">
            <p class="text-green-100 text-[10px] font-medium mb-0.5">Total Deposits</p>
            <h3 class="text-xl font-bold"><?php echo e($deposits->total()); ?></h3>
        </div>
        <div class="bg-gradient-to-br from-teal-500 to-teal-600 rounded-lg p-2 md:p-3 text-white shadow-lg">
            <p class="text-teal-100 text-[10px] font-medium mb-0.5">Total Amount</p>
            <h3 class="text-xl font-bold"><?php echo e(number_format($deposits->sum('amount')/1000000, 1)); ?>M</h3>
        </div>
        <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg p-2 md:p-3 text-white shadow-lg">
            <p class="text-blue-100 text-[10px] font-medium mb-0.5">Today</p>
            <h3 class="text-xl font-bold"><?php echo e($deposits->where('created_at', '>=', today())->count()); ?></h3>
        </div>
        <div class="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg p-2 md:p-3 text-white shadow-lg">
            <p class="text-purple-100 text-[10px] font-medium mb-0.5">This Month</p>
            <h3 class="text-xl font-bold"><?php echo e($deposits->where('created_at', '>=', now()->startOfMonth())->count()); ?></h3>
        </div>
    </div>

    <div class="bg-gradient-to-br from-green-50 via-teal-50 to-green-50 rounded-2xl shadow-lg border border-green-100 overflow-hidden mb-4">
        <form method="GET" action="<?php echo e(route('cashier.deposits.index')); ?>" x-data="{ showAdvanced: false }">
            <div class="bg-white/60 backdrop-blur-sm p-3">
                <div class="bg-white/80 rounded-xl p-2.5 border border-green-100">
                    <div class="grid grid-cols-1 md:grid-cols-12 gap-2">
                        <div class="md:col-span-5 relative">
                            <i class="fas fa-search absolute left-2.5 top-1/2 transform -translate-y-1/2 text-green-400 text-xs"></i>
                            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search member..." class="w-full pl-8 pr-2 py-1.5 text-xs border border-green-200 rounded-lg focus:ring-2 focus:ring-green-500 bg-white">
                        </div>
                        <div class="md:col-span-2 relative">
                            <i class="fas fa-sort-amount-down absolute left-2.5 top-1/2 transform -translate-y-1/2 text-teal-400 text-xs"></i>
                            <select name="sort" class="w-full pl-8 pr-2 py-1.5 text-xs border border-teal-200 rounded-lg focus:ring-2 focus:ring-teal-500 appearance-none bg-white" @change="$el.form.submit()">
                                <option value="">Sort By</option>
                                <option value="amount_high" <?php echo e(request('sort') == 'amount_high' ? 'selected' : ''); ?>>Amount (High-Low)</option>
                                <option value="amount_low" <?php echo e(request('sort') == 'amount_low' ? 'selected' : ''); ?>>Amount (Low-High)</option>
                                <option value="newest" <?php echo e(request('sort') == 'newest' ? 'selected' : ''); ?>>Newest First</option>
                                <option value="oldest" <?php echo e(request('sort') == 'oldest' ? 'selected' : ''); ?>>Oldest First</option>
                            </select>
                        </div>
                        <div class="md:col-span-1">
                            <button type="button" @click="showAdvanced = !showAdvanced" class="w-full px-2 py-1.5 text-xs bg-gradient-to-r from-green-500 to-teal-500 text-white rounded-lg hover:shadow-md transition flex items-center justify-center gap-1">
                                <i class="fas fa-sliders-h"></i>
                                <i class="fas fa-chevron-down text-[8px] transition-transform" :class="showAdvanced ? 'rotate-180' : ''"></i>
                            </button>
                        </div>
                        <div class="md:col-span-4 flex gap-1.5">
                            <button type="submit" class="flex-1 px-2 py-1.5 text-xs bg-gradient-to-r from-green-600 to-teal-600 text-white rounded-lg hover:shadow-lg transition font-semibold">
                                <i class="fas fa-search mr-1"></i>Search
                            </button>
                            <a href="<?php echo e(route('cashier.deposits.index')); ?>" class="px-2 py-1.5 text-xs bg-gradient-to-r from-gray-100 to-gray-200 text-gray-700 rounded-lg hover:shadow-md transition font-semibold">
                                <i class="fas fa-redo"></i>
                            </a>
                        </div>
                    </div>

                    <div x-show="showAdvanced" x-collapse class="mt-2 pt-2 border-t border-green-100">
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-2">
                            <div class="flex gap-1">
                                <input type="number" name="amount_min" value="<?php echo e(request('amount_min')); ?>" placeholder="Min Amount" class="w-full px-2 py-1.5 text-xs border border-yellow-200 rounded-lg focus:ring-2 focus:ring-yellow-500 bg-white" @change="$el.form.submit()">
                                <input type="number" name="amount_max" value="<?php echo e(request('amount_max')); ?>" placeholder="Max" class="w-full px-2 py-1.5 text-xs border border-yellow-200 rounded-lg focus:ring-2 focus:ring-yellow-500 bg-white" @change="$el.form.submit()">
                            </div>
                            <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" class="w-full px-2 py-1.5 text-xs border border-green-200 rounded-lg focus:ring-2 focus:ring-green-500 bg-white" @change="$el.form.submit()">
                            <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" class="w-full px-2 py-1.5 text-xs border border-green-200 rounded-lg focus:ring-2 focus:ring-green-500 bg-white" @change="$el.form.submit()">
                            <select name="per_page" class="w-full px-2 py-1.5 text-xs border border-green-200 rounded-lg focus:ring-2 focus:ring-green-500 appearance-none bg-white" @change="$el.form.submit()">
                                <option value="10" <?php echo e(request('per_page') == '10' ? 'selected' : ''); ?>>10 per page</option>
                                <option value="20" <?php echo e(request('per_page') == '20' ? 'selected' : ''); ?>>20 per page</option>
                                <option value="50" <?php echo e(request('per_page') == '50' ? 'selected' : ''); ?>>50 per page</option>
                                <option value="100" <?php echo e(request('per_page') == '100' ? 'selected' : ''); ?>>100 per page</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y-0">
                <thead class="bg-gradient-to-r from-green-600 via-teal-600 to-green-600">
                    <tr class="border-b-2 border-white/20">
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider border-r border-white/20">Date</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider border-r border-white/20">Member</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider border-r border-white/20">Amount</th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider border-r border-white/20">Description</th>
                        <th class="px-6 py-4 text-center text-xs font-bold text-white uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white">
                    <?php $__empty_1 = true; $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="transition-all duration-200 <?php echo e($loop->iteration % 2 == 0 ? 'bg-green-50' : 'bg-white'); ?> hover:bg-gradient-to-r hover:from-green-50 hover:to-teal-50 border-l-4 border-green-500">
                        <td class="px-6 py-4 whitespace-nowrap border-r border-gray-200 text-sm"><?php echo e($deposit->created_at->format('M d, Y H:i')); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap border-r border-gray-200">
                            <div class="flex items-center gap-3">
                                <?php if($deposit->member): ?>
                                <?php if($deposit->member->profile_picture): ?>
                                    <img src="<?php echo e(asset('storage/' . $deposit->member->profile_picture)); ?>" class="w-10 h-10 rounded-full object-cover ring-2 ring-green-500 ring-offset-2">
                                <?php else: ?>
                                    <div class="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-teal-600 flex items-center justify-center ring-2 ring-green-500 ring-offset-2">
                                        <span class="text-white font-bold"><?php echo e(substr($deposit->member->full_name, 0, 1)); ?></span>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <p class="text-sm font-semibold text-gray-900"><?php echo e($deposit->member->full_name); ?></p>
                                    <p class="text-xs text-gray-500"><?php echo e($deposit->member->member_id); ?></p>
                                </div>
                                <?php else: ?>
                                <span class="text-sm text-gray-500">N/A</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap border-r border-gray-200 text-sm font-bold text-green-600">+<?php echo e(number_format($deposit->amount)); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-500 border-r border-gray-200"><?php echo e($deposit->description ?? '-'); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-center">
                            <a href="<?php echo e(route('cashier.deposits.show', $deposit->id)); ?>" class="p-2 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 transition inline-block">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center">
                            <div class="flex flex-col items-center justify-center">
                                <i class="fas fa-arrow-down text-6xl text-gray-300 mb-4"></i>
                                <p class="text-gray-500 text-lg font-medium">No deposits found</p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="p-4"><?php echo e($deposits->links()); ?></div>
    </div>
</div>

<style>
@keyframes slide-right { 0% { width: 0%; } 100% { width: 100%; } }
.animate-slide-right { animation: slide-right 5s ease-out forwards; }
@keyframes slide-text { 0% { left: 0%; opacity: 1; } 95% { opacity: 1; } 100% { left: 100%; opacity: 0; } }
.animate-slide-text { animation: slide-text 5s ease-out forwards; }
tr { position: relative; }
tr::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(to right, transparent, #10b981, #14b8a6, transparent);
    opacity: 0.3;
}
tr:hover::after { opacity: 0.6; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cashier', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\Bss test\bss system new\resources\views/cashier/deposits/index.blade.php ENDPATH**/ ?>