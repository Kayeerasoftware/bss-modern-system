<?php

namespace App\Policies;

class UserPolicy
{
    //
}
