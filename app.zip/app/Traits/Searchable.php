<?php

namespace App\Traits;

trait Searchable
{
    //
}
