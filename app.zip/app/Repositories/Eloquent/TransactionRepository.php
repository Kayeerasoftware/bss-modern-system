<?php

namespace App\Repositories\Eloquent;

use App\Repositories\Interfaces\TransactionRepositoryInterface;

class TransactionRepository implements TransactionRepositoryInterface
{
    //
}
