<?php

namespace App\Http\Requests\Loans;

use Illuminate\Foundation\Http\FormRequest;

class LoanRequest extends FormRequest
{
    public function rules()
    {
        return [];
    }
}
