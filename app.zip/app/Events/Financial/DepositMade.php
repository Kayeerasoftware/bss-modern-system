<?php

namespace App\Events\Financial;

use Illuminate\Foundation\Events\Dispatchable;

class DepositMade
{
    use Dispatchable;
}
