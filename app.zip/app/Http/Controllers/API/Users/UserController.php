<?php

namespace App\Http\Controllers\Api\Users;

use App\Http\Controllers\Controller;

class UserController extends Controller
{
    //
}
