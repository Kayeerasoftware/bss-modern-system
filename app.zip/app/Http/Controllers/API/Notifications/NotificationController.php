<?php

namespace App\Http\Controllers\Api\Notifications;

use App\Http\Controllers\Controller;

class NotificationController extends Controller
{
    //
}
