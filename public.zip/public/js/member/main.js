// Member Dashboard Main JS
document.addEventListener('DOMContentLoaded', function() {
    console.log('Member dashboard loaded');
});
