<?php

namespace App\Services\Loan;

class RepaymentService
{
    //
}
