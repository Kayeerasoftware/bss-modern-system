<?php

namespace App\Models\Financial;

use Illuminate\Database\Eloquent\Model;

class Transfer extends Model
{
    //
}
