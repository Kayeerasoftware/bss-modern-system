<?php

namespace App\Policies;

class MemberPolicy
{
    //
}
