<?php

namespace App\Policies;

class TransactionPolicy
{
    //
}
