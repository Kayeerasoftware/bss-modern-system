<?php

namespace App\Http\Controllers\CEO;

use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;

class DashboardController extends AdminDashboardController
{
    // Inherits all methods from Admin DashboardController
}
