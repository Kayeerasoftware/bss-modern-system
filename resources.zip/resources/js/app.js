import './bootstrap';

// Global app initialization
document.addEventListener('DOMContentLoaded', function() {
    console.log('BSS Investment System Loaded');
});
