<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

class MemberManagementController extends Controller
{
    //
}
