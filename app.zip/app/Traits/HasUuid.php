<?php

namespace App\Traits;

trait HasUuid
{
    //
}
