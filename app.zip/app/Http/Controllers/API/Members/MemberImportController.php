<?php

namespace App\Http\Controllers\Api\Members;

use App\Http\Controllers\Controller;

class MemberImportController extends Controller
{
    //
}
