<?php

namespace App\Http\Requests\System;

use Illuminate\Foundation\Http\FormRequest;

class BackupRequest extends FormRequest
{
    public function rules()
    {
        return [];
    }
}
