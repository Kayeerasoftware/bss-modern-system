<?php

namespace App\Models\Fundraising;

use Illuminate\Database\Eloquent\Model;

class Contribution extends Model
{
    //
}
