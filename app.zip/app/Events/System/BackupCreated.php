<?php

namespace App\Events\System;

use Illuminate\Foundation\Events\Dispatchable;

class BackupCreated
{
    use Dispatchable;
}
