<?php

namespace App\Events\Loan;

use Illuminate\Foundation\Events\Dispatchable;

class LoanApproved
{
    use Dispatchable;
}
