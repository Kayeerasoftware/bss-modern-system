@php
    return redirect()->route('admin.loans.create');
@endphp
