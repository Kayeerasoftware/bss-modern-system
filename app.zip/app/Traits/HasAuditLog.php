<?php

namespace App\Traits;

trait HasAuditLog
{
    //
}
