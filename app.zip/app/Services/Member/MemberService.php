<?php

namespace App\Services\Member;

class MemberService
{
    //
}
