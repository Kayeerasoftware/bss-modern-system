<?php

namespace App\Events\Loan;

use Illuminate\Foundation\Events\Dispatchable;

class LoanRepaymentMade
{
    use Dispatchable;
}
