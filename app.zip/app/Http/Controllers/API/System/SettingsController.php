<?php

namespace App\Http\Controllers\Api\System;

use App\Http\Controllers\Controller;

class SettingsController extends Controller
{
    //
}
