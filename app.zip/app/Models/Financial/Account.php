<?php

namespace App\Models\Financial;

use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    //
}
