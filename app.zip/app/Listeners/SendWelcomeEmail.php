<?php

namespace App\Listeners;

class SendWelcomeEmail
{
    public function handle($event)
    {
        //
    }
}
