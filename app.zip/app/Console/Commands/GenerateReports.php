<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class GenerateReports extends Command
{
    protected $signature = 'reports:generate';
    protected $description = 'Generate reports';

    public function handle()
    {
        //
    }
}
