<?php

return [
    'welcome' => 'Karibu BSS Investment Group',
    'success' => 'Mchakato umekamilika kwa mafanikio',
    'error' => 'Hitilafu imetokea',
    'created' => ':item imeundwa kwa mafanikio',
    'updated' => ':item imesasishwa kwa mafanikio',
    'deleted' => ':item imefutwa kwa mafanikio',
    'not_found' => ':item haijapatikana',
    'unauthorized' => 'Huna ruhusa ya kufanya kitendo hiki',
];
