<?php

namespace App\Models\System;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    //
}
